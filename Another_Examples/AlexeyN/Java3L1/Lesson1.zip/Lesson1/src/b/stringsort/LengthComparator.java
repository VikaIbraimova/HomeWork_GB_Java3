package b.stringsort;

import java.util.Comparator;

/**
 * Created by tomag on 10.07.2016.
 */
public class LengthComparator<T extends String> implements Comparator<T> {

    @Override
    public int compare(T o1, T o2) {
        return o1.length()<o2.length() ? -1 : 0;
    }
}
