import b.stringsort.StringSort;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Created by tomag on 10.07.2016.
 */
public class StringSortTest {
    @Test
    public void init() {
        assertEquals(new StringSort().test("zzzzz","b","aaaa","cc","ggg"),"[b, cc, ggg, aaaa, zzzzz]");
        assertEquals(new StringSort().test("eeeee","ccc","dddd","bb","ffffff"),"[bb, ccc, dddd, eeeee, ffffff]");
        assertEquals(new StringSort().test("z","xx","ccc","vvvv","bbbbb"),"[z, xx, ccc, vvvv, bbbbb]");
        assertEquals(new StringSort().test("bbbbb","vvvv","ccc","xx","z"),"[z, xx, ccc, vvvv, bbbbb]");
        assertEquals(new StringSort().test("qqqqqqqqqqqqqqqqqqqq","b","dddddddd","cc","aaa"),"[b, cc, aaa, dddddddd, qqqqqqqqqqqqqqqqqqqq]");
    }
}