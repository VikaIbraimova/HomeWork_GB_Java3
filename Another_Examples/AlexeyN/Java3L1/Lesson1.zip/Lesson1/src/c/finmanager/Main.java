package c.finmanager;

import java.io.IOException;

/**
 * Created by tomag on 11.07.2016.
 */
public class Main {
    public static void main(String[] args) throws IOException {
        Control control = new Control();
        control.ask();
    }
}