package c.finmanager;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by tomag on 10.07.2016.
 */
public class Record {
    private String recordDescription;
    private /*final*/ String STATE;
    private Date date;
    private BigDecimal sum;
}
