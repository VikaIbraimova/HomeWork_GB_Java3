package a.stack;

/**
 * Created by tomag on 10.07.2016.
 */
public class StackException extends Exception {
    public StackException(String message) {
        super(message);
    }
}
